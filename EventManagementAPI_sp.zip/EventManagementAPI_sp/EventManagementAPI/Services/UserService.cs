﻿using EventManagementAPI.Data;
using EventManagementAPI.Models;
using EventManagementAPI.Models.DTOs;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;

namespace EventManagementAPI.Services
{
    public class UserService : IUserService
    {
        private readonly UserDbContext _context;

        public UserService(UserDbContext context)
        {
            _context = context;
        }

        // ✅ Logs login outcomes
        private async Task LogLoginAttemptAsync(string email, string status, string? errorMessage = null)
        {
            var parameters = new[]
            {
                new SqlParameter("@Email", email ?? string.Empty),
                new SqlParameter("@Status", status),
                new SqlParameter("@ErrorMessage", errorMessage ?? (object)DBNull.Value)
            };

            await _context.Database.ExecuteSqlRawAsync(
                "EXEC usp_LogUserLoginAttempt @Email, @Status, @ErrorMessage", parameters);
        }

        // ✅ Logs registration failures
        private async Task LogRegistrationErrorAsync(string role, string email, string errorMessage)
        {
            var parameters = new[]
            {
                new SqlParameter("@Role", role ?? "Unknown"),
                new SqlParameter("@Email", email ?? string.Empty),
                new SqlParameter("@ErrorMessage", errorMessage)
            };

            await _context.Database.ExecuteSqlRawAsync(
                "EXEC usp_LogUserRegistrationError @Role, @Email, @ErrorMessage", parameters);
        }

        // ✅ Wrapped in try-catch for logging failed registrations
        public async Task<bool> RegisterUserAsync(UserRegisterDto dto)
        {
            try
            {
                var exists = await _context.Users.AnyAsync(u => u.Email == dto.Email);
                if (exists) return false;

                var user = new User
                {
                    Name = dto.Name,
                    Email = dto.Email,
                    Password = BCrypt.Net.BCrypt.HashPassword(dto.Password),
                    ContactNumber = dto.ContactNumber,
                    Role = string.IsNullOrEmpty(dto.Role) ? "User" : dto.Role
                };

                _context.Users.Add(user);
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception ex)
            {
                await LogRegistrationErrorAsync(dto.Role ?? "Unknown", dto.Email, ex.Message);
                return false;
            }
        }

        // ✅ Wrapped in try-catch for logging login failures
        public async Task<User?> LoginUserAsync(string email, string password)
        {
            try
            {
                var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == email);

                if (user == null || !BCrypt.Net.BCrypt.Verify(password, user.Password))
                {
                    await LogLoginAttemptAsync(email, "LoginFailed", "Invalid credentials");
                    return null;
                }

                await LogLoginAttemptAsync(user.Email, "LoginSuccess");
                return user;
            }
            catch (Exception ex)
            {
                await LogLoginAttemptAsync(email, "ExceptionOccurred", ex.Message);
                return null;
            }
        }

        public async Task<bool> UpdateUserAsync(int userId, UserRegisterDto dto)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null) return false;

            user.Name = dto.Name;
            user.Email = dto.Email;
            user.ContactNumber = dto.ContactNumber;
            user.Password = BCrypt.Net.BCrypt.HashPassword(dto.Password);
            user.Role = dto.Role;

            _context.Users.Update(user);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<List<User>> GetAllUsersAsync()
        {
            return await _context.Users.ToListAsync();
        }

        public async Task<bool> DeleteUserAsync(int userId)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null) return false;

            _context.Users.Remove(user);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> UpdateSelfAsync(int userId, UserRegisterDto dto)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null) return false;

            user.Name = dto.Name;
            user.Email = dto.Email;
            user.ContactNumber = dto.ContactNumber;
            user.Password = BCrypt.Net.BCrypt.HashPassword(dto.Password);
            _context.Users.Update(user);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<User?> GetUserByIdAsync(int userId)
        {
            return await _context.Users.FindAsync(userId);
        }

        public async Task<bool> UpdateUserDetailsAsync(int userId, string name, string contactNumber)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null) return false;

            user.Name = name;
            user.ContactNumber = contactNumber;
            _context.Users.Update(user);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}