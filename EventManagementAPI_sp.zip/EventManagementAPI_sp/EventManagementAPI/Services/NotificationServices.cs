﻿using EventManagementAPI.Data;
using EventManagementAPI.Models;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace EventManagementAPI.Services
{
    public class NotificationServices
    {
        private readonly UserDbContext _context;

        public NotificationServices(UserDbContext context)
        {
            _context = context;
        }

        public void SendNotification(int userId, int eventId, bool bookingStatus, string eventName, DateTime eventDate, string customMessage = null)
        {
            var message = customMessage ?? (bookingStatus
                ? $"Your booking for {eventName} on {eventDate:dd-MM-yyyy} is confirmed."
                : $"Your booking for {eventName} on {eventDate:dd-MM-yyyy} failed.");

            var parameters = new[]
            {
                new SqlParameter("@UserID", userId),
                new SqlParameter("@EventID", eventId),
                new SqlParameter("@Message", message),
                new SqlParameter("@SentTimestamp", DateTime.Now)
            };

            _context.Database.ExecuteSqlRaw("EXEC usp_AddNotification @UserID, @EventID, @Message, @SentTimestamp", parameters);
        }

        public List<Notifications> GetNotificationsByUserId(int userId)
        {
            var param = new SqlParameter("@UserID", userId);
            return _context.Notifications
                .FromSqlRaw("EXEC usp_GetNotificationsByUserID @UserID", param)
                .ToList();
        }
    }
}