﻿using Microsoft.Data.SqlClient;

using Microsoft.EntityFrameworkCore;

using EventManagementAPI.Models;

using EventManagementAPI.Data;

public class CategoryServices

{

    private readonly UserDbContext _context;

    public CategoryServices(UserDbContext context)

    {

        _context = context;

    }

    public List<Category> GetAllCategories()

    {

        return _context.Set<Category>()

            .FromSqlRaw("EXEC sp_GetAllCategories")

            .ToList();

    }

    public Category GetCategory(int id)

    {

        var param = new SqlParameter("@CategoryID", id);

        return _context.Set<Category>()

            .FromSqlRaw("EXEC sp_GetCategoryById @CategoryID", param)

            .AsEnumerable()

            .FirstOrDefault();

    }

    public void AddCategory(Category category)

    {

        var param = new SqlParameter("@CategoryName", category.CategoryName);

        _context.Database.ExecuteSqlRaw("EXEC sp_AddCategory @CategoryName", param);

    }

}

