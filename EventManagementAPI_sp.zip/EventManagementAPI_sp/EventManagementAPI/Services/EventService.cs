﻿using EventManagementAPI.Data;
using EventManagementAPI.Models;
using EventManagementAPI.Models.DTOs;
using Microsoft.EntityFrameworkCore;

namespace EventManagementAPI.Services
{
    public class EventService : IEventService
    {
        private readonly UserDbContext _context;

        public EventService(UserDbContext context)
        {
            _context = context;
        }

        public async Task<bool> CreateEventAsync(EventDto dto)
        {
            var categoryExists = await _context.Categories.AnyAsync(c => c.CategoryID == dto.CategoryID);
            var locationExists = await _context.Locations.AnyAsync(l => l.LocationID == dto.LocationID);

            if (!categoryExists || !locationExists)
                return false;

            var newEvent = new Event
            {
                Name = dto.Name,
                CategoryID = dto.CategoryID,
                LocationID = dto.LocationID,
                StartDate = dto.StartDate,
                EndDate = dto.EndDate,
                UserID = dto.UserID,
                Description = dto.Description,
                IsPrice = dto.IsPrice,
                Price = dto.Price,
                IsActive = dto.IsActive
            };

            _context.Events.Add(newEvent);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> UpdateEventAsync(int eventId, EventDto dto)
        {
            var existingEvent = await _context.Events.FindAsync(eventId);
            if (existingEvent == null) return false;

            existingEvent.Name = dto.Name;
            existingEvent.CategoryID = dto.CategoryID;
            existingEvent.LocationID = dto.LocationID;
            existingEvent.StartDate = dto.StartDate;
            existingEvent.EndDate = dto.EndDate;
            existingEvent.UserID = dto.UserID;
            existingEvent.Description = dto.Description;
            existingEvent.IsPrice = dto.IsPrice; // ✅ Corrected
            existingEvent.Price = dto.Price;
            existingEvent.IsActive = dto.IsActive;

            _context.Events.Update(existingEvent);
            await _context.SaveChangesAsync();
            return true;
        }


        public async Task<List<Event>> GetAllEventsAsync()
        {
            return await _context.Events.ToListAsync();
        }

        public async Task<Event?> GetEventByIdAsync(int eventId)
        {
            return await _context.Events.FindAsync(eventId);
        }

        public async Task<bool> DeleteEventAsync(int eventId)
        {
            var eventToDelete = await _context.Events.FindAsync(eventId);
            if (eventToDelete == null) return false;

            _context.Events.Remove(eventToDelete);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}