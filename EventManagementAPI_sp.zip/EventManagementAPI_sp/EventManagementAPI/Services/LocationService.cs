﻿using EventManagementAPI.Data;
using EventManagementAPI.Models;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace EventManagementAPI.Services
{
    public class LocationService
    {
        private readonly UserDbContext _context;

        public LocationService(UserDbContext context)
        {
            _context = context;
        }

        public List<Location> GetLocationDetails()
        {
            return _context.Locations
                .FromSqlRaw("EXEC usp_GetAllLocations")
                .ToList();
        }

        public Location GetLocationById(int id)
        {
            return _context.Locations
                .FromSqlRaw("EXEC usp_GetLocationById @LocationID",
                    new SqlParameter("@LocationID", id))
                .AsEnumerable()
                .FirstOrDefault();
        }

        public void EnterLocationDetails(Location location)
        {
            var parameters = new[]
            {
                new SqlParameter("@LocationName", location.LocationName),
                new SqlParameter("@Capacity", location.Capacity),
                new SqlParameter("@Address", location.Address),
                new SqlParameter("@City", location.City),
                new SqlParameter("@State", location.State),
                new SqlParameter("@Country", location.Country),
                new SqlParameter("@PostalCode", location.PostalCode),
                new SqlParameter("@PrimaryContact", location.PrimaryContact),
                new SqlParameter("@SecondaryContact", (object?)location.SecondaryContact ?? DBNull.Value)
            };

            _context.Database.ExecuteSqlRaw("EXEC usp_AddLocation @LocationName, @Capacity, @Address, @City, @State, @Country, @PostalCode, @PrimaryContact, @SecondaryContact", parameters);
        }

        public void UpdateLocationDetails(Location location, int id)
        {
            var parameters = new[]
            {
                new SqlParameter("@LocationID", id),
                new SqlParameter("@LocationName", location.LocationName),
                new SqlParameter("@Capacity", location.Capacity),
                new SqlParameter("@Address", location.Address),
                new SqlParameter("@City", location.City),
                new SqlParameter("@State", location.State),
                new SqlParameter("@Country", location.Country),
                new SqlParameter("@PostalCode", location.PostalCode),
                new SqlParameter("@PrimaryContact", location.PrimaryContact),
                new SqlParameter("@SecondaryContact", (object?)location.SecondaryContact ?? DBNull.Value)
            };

            _context.Database.ExecuteSqlRaw("EXEC usp_UpdateLocation @LocationID, @LocationName, @Capacity, @Address, @City, @State, @Country, @PostalCode, @PrimaryContact, @SecondaryContact", parameters);
        }

        public void RemoveLocationDetails(int id)
        {
            var parameter = new SqlParameter("@LocationID", id);
            _context.Database.ExecuteSqlRaw("EXEC usp_DeleteLocation @LocationID", parameter);
        }
    }
}