﻿using EventManagementAPI.Models.DTOs;

namespace EventManagementAPI.Services
{
    public interface ITicketService
    {
        Task<List<TicketDetailsDto>> GetAllTicketDetailsAsync();
        Task<List<TicketDetailsDto>> GetTicketsByUserIdAsync(int userId);
        Task<TicketDetailsDto?> GetTicketByIdAsync(int ticketId);
        Task<bool> IsTicketBookedAsync(int userId, int eventId);
    }
}
