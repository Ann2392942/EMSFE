﻿using EventManagementAPI.Models;
using EventManagementAPI.Models.DTOs;

namespace EventManagementAPI.Services
{
    public interface IEventService
    {
        Task<bool> CreateEventAsync(EventDto dto);
        Task<List<Event>> GetAllEventsAsync();
        Task<Event?> GetEventByIdAsync(int eventId);
        Task<bool> UpdateEventAsync(int eventId, EventDto dto);
        Task<bool> DeleteEventAsync(int eventId);
    }
}
