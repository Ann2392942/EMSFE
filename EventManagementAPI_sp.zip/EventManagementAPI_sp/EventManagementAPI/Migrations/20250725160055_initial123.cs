﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EventManagementAPI.Migrations
{
    /// <inheritdoc />
    public partial class initial123 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Events_Locations_LocationID",
                table: "Events");

            migrationBuilder.DropForeignKey(
                name: "FK_Events_tCategories_CategoryID",
                table: "Events");

            migrationBuilder.DropForeignKey(
                name: "FK_Feedbacks_Events_EventID",
                table: "Feedbacks");

            migrationBuilder.DropForeignKey(
                name: "FK_Feedbacks_Tickets_TicketID",
                table: "Feedbacks");

            migrationBuilder.DropForeignKey(
                name: "FK_Feedbacks_Users_UserID",
                table: "Feedbacks");

            migrationBuilder.DropForeignKey(
                name: "FK_Notifications_Events_EventID",
                table: "Notifications");

            migrationBuilder.DropForeignKey(
                name: "FK_Notifications_Users_UserID",
                table: "Notifications");

            migrationBuilder.DropForeignKey(
                name: "FK_Payments_Events_EventID",
                table: "Payments");

            migrationBuilder.DropForeignKey(
                name: "FK_Payments_Users_UserID",
                table: "Payments");

            migrationBuilder.DropForeignKey(
                name: "FK_Tickets_Events_EventID",
                table: "Tickets");

            migrationBuilder.DropForeignKey(
                name: "FK_Tickets_Users_UserID",
                table: "Tickets");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Users",
                table: "Users");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Tickets",
                table: "Tickets");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Payments",
                table: "Payments");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Notifications",
                table: "Notifications");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Locations",
                table: "Locations");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Feedbacks",
                table: "Feedbacks");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Events",
                table: "Events");

            migrationBuilder.RenameTable(
                name: "Users",
                newName: "tUsers");

            migrationBuilder.RenameTable(
                name: "Tickets",
                newName: "tTickets");

            migrationBuilder.RenameTable(
                name: "Payments",
                newName: "tPayments");

            migrationBuilder.RenameTable(
                name: "Notifications",
                newName: "tNotifications");

            migrationBuilder.RenameTable(
                name: "Locations",
                newName: "tLocations");

            migrationBuilder.RenameTable(
                name: "Feedbacks",
                newName: "tFeedbacks");

            migrationBuilder.RenameTable(
                name: "Events",
                newName: "tEvents");

            migrationBuilder.RenameIndex(
                name: "IX_Users_Email",
                table: "tUsers",
                newName: "IX_tUsers_Email");

            migrationBuilder.RenameIndex(
                name: "IX_Tickets_UserID",
                table: "tTickets",
                newName: "IX_tTickets_UserID");

            migrationBuilder.RenameIndex(
                name: "IX_Tickets_EventID",
                table: "tTickets",
                newName: "IX_tTickets_EventID");

            migrationBuilder.RenameIndex(
                name: "IX_Payments_UserID",
                table: "tPayments",
                newName: "IX_tPayments_UserID");

            migrationBuilder.RenameIndex(
                name: "IX_Payments_EventID",
                table: "tPayments",
                newName: "IX_tPayments_EventID");

            migrationBuilder.RenameIndex(
                name: "IX_Notifications_UserID",
                table: "tNotifications",
                newName: "IX_tNotifications_UserID");

            migrationBuilder.RenameIndex(
                name: "IX_Notifications_EventID",
                table: "tNotifications",
                newName: "IX_tNotifications_EventID");

            migrationBuilder.RenameIndex(
                name: "IX_Feedbacks_UserID",
                table: "tFeedbacks",
                newName: "IX_tFeedbacks_UserID");

            migrationBuilder.RenameIndex(
                name: "IX_Feedbacks_TicketID",
                table: "tFeedbacks",
                newName: "IX_tFeedbacks_TicketID");

            migrationBuilder.RenameIndex(
                name: "IX_Feedbacks_EventID",
                table: "tFeedbacks",
                newName: "IX_tFeedbacks_EventID");

            migrationBuilder.RenameIndex(
                name: "IX_Events_LocationID",
                table: "tEvents",
                newName: "IX_tEvents_LocationID");

            migrationBuilder.RenameIndex(
                name: "IX_Events_CategoryID",
                table: "tEvents",
                newName: "IX_tEvents_CategoryID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_tUsers",
                table: "tUsers",
                column: "UserID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_tTickets",
                table: "tTickets",
                column: "TicketID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_tPayments",
                table: "tPayments",
                column: "PaymentID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_tNotifications",
                table: "tNotifications",
                column: "NotificationID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_tLocations",
                table: "tLocations",
                column: "LocationID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_tFeedbacks",
                table: "tFeedbacks",
                column: "FeedbackID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_tEvents",
                table: "tEvents",
                column: "EventID");

            migrationBuilder.AddForeignKey(
                name: "FK_tEvents_tCategories_CategoryID",
                table: "tEvents",
                column: "CategoryID",
                principalTable: "tCategories",
                principalColumn: "CategoryID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_tEvents_tLocations_LocationID",
                table: "tEvents",
                column: "LocationID",
                principalTable: "tLocations",
                principalColumn: "LocationID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_tFeedbacks_tEvents_EventID",
                table: "tFeedbacks",
                column: "EventID",
                principalTable: "tEvents",
                principalColumn: "EventID",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_tFeedbacks_tTickets_TicketID",
                table: "tFeedbacks",
                column: "TicketID",
                principalTable: "tTickets",
                principalColumn: "TicketID");

            migrationBuilder.AddForeignKey(
                name: "FK_tFeedbacks_tUsers_UserID",
                table: "tFeedbacks",
                column: "UserID",
                principalTable: "tUsers",
                principalColumn: "UserID",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_tNotifications_tEvents_EventID",
                table: "tNotifications",
                column: "EventID",
                principalTable: "tEvents",
                principalColumn: "EventID");

            migrationBuilder.AddForeignKey(
                name: "FK_tNotifications_tUsers_UserID",
                table: "tNotifications",
                column: "UserID",
                principalTable: "tUsers",
                principalColumn: "UserID");

            migrationBuilder.AddForeignKey(
                name: "FK_tPayments_tEvents_EventID",
                table: "tPayments",
                column: "EventID",
                principalTable: "tEvents",
                principalColumn: "EventID");

            migrationBuilder.AddForeignKey(
                name: "FK_tPayments_tUsers_UserID",
                table: "tPayments",
                column: "UserID",
                principalTable: "tUsers",
                principalColumn: "UserID");

            migrationBuilder.AddForeignKey(
                name: "FK_tTickets_tEvents_EventID",
                table: "tTickets",
                column: "EventID",
                principalTable: "tEvents",
                principalColumn: "EventID");

            migrationBuilder.AddForeignKey(
                name: "FK_tTickets_tUsers_UserID",
                table: "tTickets",
                column: "UserID",
                principalTable: "tUsers",
                principalColumn: "UserID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_tEvents_tCategories_CategoryID",
                table: "tEvents");

            migrationBuilder.DropForeignKey(
                name: "FK_tEvents_tLocations_LocationID",
                table: "tEvents");

            migrationBuilder.DropForeignKey(
                name: "FK_tFeedbacks_tEvents_EventID",
                table: "tFeedbacks");

            migrationBuilder.DropForeignKey(
                name: "FK_tFeedbacks_tTickets_TicketID",
                table: "tFeedbacks");

            migrationBuilder.DropForeignKey(
                name: "FK_tFeedbacks_tUsers_UserID",
                table: "tFeedbacks");

            migrationBuilder.DropForeignKey(
                name: "FK_tNotifications_tEvents_EventID",
                table: "tNotifications");

            migrationBuilder.DropForeignKey(
                name: "FK_tNotifications_tUsers_UserID",
                table: "tNotifications");

            migrationBuilder.DropForeignKey(
                name: "FK_tPayments_tEvents_EventID",
                table: "tPayments");

            migrationBuilder.DropForeignKey(
                name: "FK_tPayments_tUsers_UserID",
                table: "tPayments");

            migrationBuilder.DropForeignKey(
                name: "FK_tTickets_tEvents_EventID",
                table: "tTickets");

            migrationBuilder.DropForeignKey(
                name: "FK_tTickets_tUsers_UserID",
                table: "tTickets");

            migrationBuilder.DropPrimaryKey(
                name: "PK_tUsers",
                table: "tUsers");

            migrationBuilder.DropPrimaryKey(
                name: "PK_tTickets",
                table: "tTickets");

            migrationBuilder.DropPrimaryKey(
                name: "PK_tPayments",
                table: "tPayments");

            migrationBuilder.DropPrimaryKey(
                name: "PK_tNotifications",
                table: "tNotifications");

            migrationBuilder.DropPrimaryKey(
                name: "PK_tLocations",
                table: "tLocations");

            migrationBuilder.DropPrimaryKey(
                name: "PK_tFeedbacks",
                table: "tFeedbacks");

            migrationBuilder.DropPrimaryKey(
                name: "PK_tEvents",
                table: "tEvents");

            migrationBuilder.RenameTable(
                name: "tUsers",
                newName: "Users");

            migrationBuilder.RenameTable(
                name: "tTickets",
                newName: "Tickets");

            migrationBuilder.RenameTable(
                name: "tPayments",
                newName: "Payments");

            migrationBuilder.RenameTable(
                name: "tNotifications",
                newName: "Notifications");

            migrationBuilder.RenameTable(
                name: "tLocations",
                newName: "Locations");

            migrationBuilder.RenameTable(
                name: "tFeedbacks",
                newName: "Feedbacks");

            migrationBuilder.RenameTable(
                name: "tEvents",
                newName: "Events");

            migrationBuilder.RenameIndex(
                name: "IX_tUsers_Email",
                table: "Users",
                newName: "IX_Users_Email");

            migrationBuilder.RenameIndex(
                name: "IX_tTickets_UserID",
                table: "Tickets",
                newName: "IX_Tickets_UserID");

            migrationBuilder.RenameIndex(
                name: "IX_tTickets_EventID",
                table: "Tickets",
                newName: "IX_Tickets_EventID");

            migrationBuilder.RenameIndex(
                name: "IX_tPayments_UserID",
                table: "Payments",
                newName: "IX_Payments_UserID");

            migrationBuilder.RenameIndex(
                name: "IX_tPayments_EventID",
                table: "Payments",
                newName: "IX_Payments_EventID");

            migrationBuilder.RenameIndex(
                name: "IX_tNotifications_UserID",
                table: "Notifications",
                newName: "IX_Notifications_UserID");

            migrationBuilder.RenameIndex(
                name: "IX_tNotifications_EventID",
                table: "Notifications",
                newName: "IX_Notifications_EventID");

            migrationBuilder.RenameIndex(
                name: "IX_tFeedbacks_UserID",
                table: "Feedbacks",
                newName: "IX_Feedbacks_UserID");

            migrationBuilder.RenameIndex(
                name: "IX_tFeedbacks_TicketID",
                table: "Feedbacks",
                newName: "IX_Feedbacks_TicketID");

            migrationBuilder.RenameIndex(
                name: "IX_tFeedbacks_EventID",
                table: "Feedbacks",
                newName: "IX_Feedbacks_EventID");

            migrationBuilder.RenameIndex(
                name: "IX_tEvents_LocationID",
                table: "Events",
                newName: "IX_Events_LocationID");

            migrationBuilder.RenameIndex(
                name: "IX_tEvents_CategoryID",
                table: "Events",
                newName: "IX_Events_CategoryID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Users",
                table: "Users",
                column: "UserID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Tickets",
                table: "Tickets",
                column: "TicketID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Payments",
                table: "Payments",
                column: "PaymentID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Notifications",
                table: "Notifications",
                column: "NotificationID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Locations",
                table: "Locations",
                column: "LocationID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Feedbacks",
                table: "Feedbacks",
                column: "FeedbackID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Events",
                table: "Events",
                column: "EventID");

            migrationBuilder.AddForeignKey(
                name: "FK_Events_Locations_LocationID",
                table: "Events",
                column: "LocationID",
                principalTable: "Locations",
                principalColumn: "LocationID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Events_tCategories_CategoryID",
                table: "Events",
                column: "CategoryID",
                principalTable: "tCategories",
                principalColumn: "CategoryID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Feedbacks_Events_EventID",
                table: "Feedbacks",
                column: "EventID",
                principalTable: "Events",
                principalColumn: "EventID",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Feedbacks_Tickets_TicketID",
                table: "Feedbacks",
                column: "TicketID",
                principalTable: "Tickets",
                principalColumn: "TicketID");

            migrationBuilder.AddForeignKey(
                name: "FK_Feedbacks_Users_UserID",
                table: "Feedbacks",
                column: "UserID",
                principalTable: "Users",
                principalColumn: "UserID",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Notifications_Events_EventID",
                table: "Notifications",
                column: "EventID",
                principalTable: "Events",
                principalColumn: "EventID");

            migrationBuilder.AddForeignKey(
                name: "FK_Notifications_Users_UserID",
                table: "Notifications",
                column: "UserID",
                principalTable: "Users",
                principalColumn: "UserID");

            migrationBuilder.AddForeignKey(
                name: "FK_Payments_Events_EventID",
                table: "Payments",
                column: "EventID",
                principalTable: "Events",
                principalColumn: "EventID");

            migrationBuilder.AddForeignKey(
                name: "FK_Payments_Users_UserID",
                table: "Payments",
                column: "UserID",
                principalTable: "Users",
                principalColumn: "UserID");

            migrationBuilder.AddForeignKey(
                name: "FK_Tickets_Events_EventID",
                table: "Tickets",
                column: "EventID",
                principalTable: "Events",
                principalColumn: "EventID");

            migrationBuilder.AddForeignKey(
                name: "FK_Tickets_Users_UserID",
                table: "Tickets",
                column: "UserID",
                principalTable: "Users",
                principalColumn: "UserID");
        }
    }
}
