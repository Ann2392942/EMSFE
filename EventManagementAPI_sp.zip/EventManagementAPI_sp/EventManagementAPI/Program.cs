﻿using EventManagementAPI.Controllers;

using EventManagementAPI.Data;

using EventManagementAPI.Services;

using Microsoft.AspNetCore.Authentication.JwtBearer;

using Microsoft.EntityFrameworkCore;

using Microsoft.IdentityModel.Tokens;

using Microsoft.OpenApi.Models;

using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Add DbContext

builder.Services.AddDbContext<UserDbContext>(options =>

    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddScoped<UserService>();

builder.Services.AddScoped<CategoryServices>();

builder.Services.AddScoped<FeedbackService>();

builder.Services.AddScoped<EventService>();

builder.Services.AddScoped<LocationService>();

builder.Services.AddScoped<BookingService>();

builder.Services.AddScoped<NotificationServices>();
builder.Services.AddScoped<ITicketService, TicketService>();


// Register services

builder.Services.AddScoped<IUserService, UserService>();

builder.Services.AddScoped<IEventService, EventService>();

builder.Services.AddSingleton<TokenService>();

// Add Controllers and Swagger

builder.Services.AddControllers();

builder.Services.AddEndpointsApiExplorer();

builder.Services.AddCors(options =>

{

    options.AddPolicy("AllowAngularApp",

        policy => policy.WithOrigins("http://localhost:4200") // your Angular app URL

                        .AllowAnyHeader()

                        .AllowAnyMethod());

});


// ✅ Add Swagger JWT support

builder.Services.AddSwaggerGen(options =>

{

    options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme

    {

        Name = "Authorization",

        Type = SecuritySchemeType.ApiKey,

        Scheme = "Bearer",

        BearerFormat = "JWT",

        In = ParameterLocation.Header,

        Description = "Enter 'Bearer' followed by your JWT token.\nExample: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."

    });

    options.AddSecurityRequirement(new OpenApiSecurityRequirement

    {

        {

            new OpenApiSecurityScheme

            {

                Reference = new OpenApiReference

                {

                    Type = ReferenceType.SecurityScheme,

                    Id = "Bearer"

                }

            },

            new string[] {}

        }

    });

});

// ✅ JWT Authentication

var jwtKey = builder.Configuration["Jwt:Key"];

var jwtIssuer = builder.Configuration["Jwt:Issuer"];

var jwtAudience = builder.Configuration["Jwt:Audience"];

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)

    .AddJwtBearer(options =>

    {

        options.TokenValidationParameters = new TokenValidationParameters

        {

            ValidateIssuer = true,

            ValidateAudience = true,

            ValidateLifetime = true,

            ValidateIssuerSigningKey = true,

            ValidIssuer = builder.Configuration["Jwt:Issuer"],

            ValidAudience = builder.Configuration["Jwt:Audience"],

            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]))

        };

    });


builder.Services.AddAuthorization();

var app = builder.Build();

// ✅ Middleware order

app.UseCors("AllowAngularApp");

app.UseSwagger();

app.UseSwaggerUI();

app.UseRouting();

app.UseAuthentication(); // Must come before UseAuthorization

app.UseAuthorization();

app.MapControllers();

app.Run();

