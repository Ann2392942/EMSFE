﻿
using Microsoft.EntityFrameworkCore;


using EventManagementAPI.Models;

namespace EventManagementAPI.Data
{
    
    // It tells Entity Framework how to connect to the database and which tables to manage.
    public class UserDbContext : DbContext
    {

        
        public UserDbContext(DbContextOptions<UserDbContext> options) : base(options) { }

       
        public DbSet<User> Users { get; set; }         // Table for users
        public DbSet<Event> Events { get; set; }       // Table for events
        public DbSet<Location> Locations { get; set; } // Table for event locations
        public DbSet<Category> Categories { get; set; } // Table for event categories
        public DbSet<Tickets> Tickets { get; set; }
        public DbSet<Notifications> Notifications { get; set; }
        public DbSet<Payments> Payments { get; set; }
        public DbSet<Feedbacks> Feedbacks { get; set; }


       
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Category>().ToTable("tCategories"); 
            modelBuilder.Entity<Payments>().ToTable("tPayments");
            modelBuilder.Entity<Event>().ToTable("tEvents");
            modelBuilder.Entity<Feedbacks>().ToTable("tFeedbacks");
            modelBuilder.Entity<Location>().ToTable("tLocations");
            modelBuilder.Entity<Notifications>().ToTable("tNotifications");
            modelBuilder.Entity<Tickets>().ToTable("tTickets");
            modelBuilder.Entity<User>().ToTable("tUsers");


            // Configure the Event table
            modelBuilder.Entity<Event>(entity =>
            {
                entity.HasKey(e => e.EventID);
                entity.HasOne<Category>()
                          .WithMany()
                          .HasForeignKey(e => e.CategoryID);


                entity.HasOne<Location>()
                      .WithMany()
                      .HasForeignKey(e => e.LocationID);
            }
             );

            modelBuilder.Entity<Location>(entity =>
            {
                entity.HasKey(l => l.LocationID);
                entity.Property(l => l.LocationName).IsRequired().HasMaxLength(255);
                entity.Property(l => l.PrimaryContact).IsRequired().HasMaxLength(15);
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.HasKey(u => u.UserID);
                entity.Property(u => u.Name).IsRequired().HasMaxLength(255);
                entity.Property(u => u.Email).IsRequired().HasMaxLength(255);
                entity.HasIndex(u => u.Email).IsUnique();
                entity.Property(u => u.Password).IsRequired().HasMaxLength(255);
            });

            modelBuilder.Entity<Tickets>(entity =>
            {
                entity.HasKey(t => t.TicketID);
                entity.Property(t => t.BookingDate).IsRequired();
                entity.Property(t => t.Status).IsRequired().HasMaxLength(50);

                entity.HasOne<Event>()
                      .WithMany(e => e.Tickets)
                      .HasForeignKey(t => t.EventID)
                      .OnDelete(DeleteBehavior.NoAction);

                entity.HasOne<User>()
                      .WithMany(u => u.Tickets)
                      .HasForeignKey(t => t.UserID)
                      .OnDelete(DeleteBehavior.NoAction);
                entity.Property(t => t.TicketCount).HasDefaultValue(1);
            });
            modelBuilder.Entity<Notifications>(entity =>
            {
                entity.HasKey(n => n.NotificationID);
                entity.Property(n => n.Message).IsRequired();
                entity.Property(n => n.SentTimestamp).IsRequired();
                entity.HasOne<User>()
                      .WithMany(u => u.Notifications)
                      .HasForeignKey(n => n.UserID)
                      .OnDelete(DeleteBehavior.NoAction);

                entity.HasOne<Event>()
                      .WithMany(e => e.Notifications)
                      .HasForeignKey(n => n.EventID)
                      .OnDelete(DeleteBehavior.NoAction);
            });
            modelBuilder.Entity<Feedbacks>(entity =>
            {
                entity.HasKey(f => f.FeedbackID);
                entity.Property(f => f.Rating).IsRequired();
                entity.Property(f => f.SubmittedTimestamp).IsRequired();
                entity.HasOne<Event>()
                      .WithMany(e => e.Feedbacks)
                      .HasForeignKey(f => f.EventID)
                      .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne<User>()
                      .WithMany(u => u.Feedbacks)
                      .HasForeignKey(f => f.UserID)
                      .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne<Tickets>()
                      .WithOne(t => t.Feedback)
                      .HasForeignKey<Feedbacks>(f => f.TicketID)
                      .OnDelete(DeleteBehavior.NoAction);
            });

            modelBuilder.Entity<Payments>(entity =>
            {
                entity.HasKey(p => p.PaymentID);
                entity.Property(p => p.Amount).IsRequired().HasColumnType("decimal(10, 2)");
                entity.Property(p => p.PaymentDate).IsRequired();
                entity.Property(p => p.PaymentStatus).IsRequired().HasMaxLength(50);
                entity.HasOne<User>()
                      .WithMany(u => u.Payments)
                      .HasForeignKey(p => p.UserID)
                      .OnDelete(DeleteBehavior.NoAction);
                entity.HasOne<Event>()
                      .WithMany(e => e.Payments)
                      .HasForeignKey(p => p.EventID)
                      .OnDelete(DeleteBehavior.NoAction);
            });
        }
    }
}
