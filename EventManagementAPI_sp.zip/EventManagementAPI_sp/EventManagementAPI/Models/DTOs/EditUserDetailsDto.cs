﻿namespace EventManagementAPI.Models.DTOs
{
    public class EditUserDetailsDto
    {
        public string Name { get; set; }
        public string ContactNumber { get; set; }
    }
}
