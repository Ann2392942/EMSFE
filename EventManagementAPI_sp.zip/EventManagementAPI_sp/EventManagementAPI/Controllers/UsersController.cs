﻿// These lines import necessary features from ASP.NET Core and your project.
using Microsoft.AspNetCore.Mvc; // Enables building web APIs
using Microsoft.AspNetCore.Authorization; // Enables role-based access control
using EventManagementAPI.Models.DTOs; // Imports data transfer objects like UserRegisterDto and UserLoginDto
using EventManagementAPI.Services; // Imports services like IUserService and TokenService

namespace EventManagementAPI.Controllers
{
    // Marks this class as an API controller
    [ApiController]

    // Sets the base route for this controller to "api/users"
    [Route("api/users")]
    public class UsersController : ControllerBase
    {
        private readonly IUserService _userService;
        private readonly TokenService _tokenService;

        public UsersController(IUserService userService, TokenService tokenService)
        {
            _userService = userService;
            _tokenService = tokenService;
        }

        [HttpPost("register-user")]
        public async Task<IActionResult> RegisterUser([FromBody] UserRegisterDto dto)
        {
            dto.Role = "User";
            var success = await _userService.RegisterUserAsync(dto);
            if (!success) return Conflict("User already exists.");
            return Ok("User registered successfully.");
        }

        [HttpPost("register-admin")]
        //[Authorize(Roles = "Admin")]
        public async Task<IActionResult> RegisterAdmin([FromBody] UserRegisterDto dto)
        {
            dto.Role = "Admin";
            var success = await _userService.RegisterUserAsync(dto);
            if (!success) return Conflict("Admin already exists.");
            return Ok("Admin registered successfully.");
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] UserLoginDto dto)
        {
            var user = await _userService.LoginUserAsync(dto.Email, dto.Password);
            if (user == null) return Unauthorized("Invalid credentials.");
            var token = _tokenService.CreateToken(user);
            return Ok(new { Message = "Login successful", Token = token, Role = user.Role });


            //var token = _tokenService.CreateToken(user);
            //return Ok(new { Message = "Login successful", Token = token, Role = user.Role });
        }

        [HttpPut("update-self/{id}")]
        //[Authorize]
        public async Task<IActionResult> UpdateSelf(int id, [FromBody] UserRegisterDto dto)
        {
            var updated = await _userService.UpdateSelfAsync(id, dto);
            if (!updated) return NotFound("User not found.");
            return Ok("User profile updated successfully.");
        }

        [HttpPut("update-user/{id}")]
        //[Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateUserByAdmin(int id, [FromBody] UserRegisterDto dto)
        {
            var updated = await _userService.UpdateUserAsync(id, dto);
            if (!updated) return NotFound("User not found.");
            return Ok("User updated by admin.");
        }

        // Endpoint for Admins to get a list of all users
        //[Authorize(Roles = "Admin")] // Only Admins can access this
        [HttpGet("all")] // Handles GET requests to "api/users/all"
        public async Task<IActionResult> GetAllUsers()
        {
            // Get all users from the service
            var users = await _userService.GetAllUsersAsync();

            // Return the list of users
            return Ok(users);
        }

        // Endpoint for Admins to delete a user
        //[Authorize(Roles = "Admin")] // Only Admins can access this
        [HttpDelete("delete/{id}")] // Handles DELETE requests to "api/users/delete/{id}"
        public async Task<IActionResult> DeleteUser(int id)
        {
            // Try to delete the user with the given ID
            var deleted = await _userService.DeleteUserAsync(id);

            // If deletion fails, return 404 Not Found
            if (!deleted) return NotFound("User not found.");

            // If successful, return 200 OK
            return Ok("User deleted successfully.");
        }
        // Add these methods to your UsersController class

        [HttpGet("details/{id}")]
        //[Authorize]
        public async Task<IActionResult> GetUserDetails(int id)
        {
            var user = await _userService.GetUserByIdAsync(id);
            if (user == null) return NotFound("User not found.");

            var userDetails = new
            {
                UserID = user.UserID,
                Name = user.Name,
                Email = user.Email,
                ContactNumber = user.ContactNumber,
                Role = user.Role
            };

            return Ok(userDetails);
        }

        [HttpPut("edit-details/{id}")]
        //[Authorize]
        public async Task<IActionResult> EditUserDetails(int id, [FromBody] EditUserDetailsDto dto)
        {
            if (string.IsNullOrWhiteSpace(dto.Name) || string.IsNullOrWhiteSpace(dto.ContactNumber))
            {
                return BadRequest("Name and Contact Number are required.");
            }

            var updated = await _userService.UpdateUserDetailsAsync(id, dto.Name, dto.ContactNumber);
            if (!updated) return NotFound("User not found.");

            return Ok("User details updated successfully.");
        }






    }
}
